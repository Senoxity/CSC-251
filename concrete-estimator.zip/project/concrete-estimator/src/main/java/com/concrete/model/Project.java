package com.concrete.model;

/**
 * Represents a concrete pad construction project estimate.
 */
public class Project {

    // Slab type presets
    public enum SlabType {
        RESIDENTIAL_PAD("Residential Pad", 4.0, 125.0, 20.0, 20.0),
        GARAGE_WORKSHOP_PAD("Garage / Workshop Pad", 5.0, 140.0, 20.0, 40.0),
        SMALL_WAREHOUSE_SLAB("Small Warehouse Slab", 6.0, 155.0, 50.0, 100.0),
        MID_WAREHOUSE_SLAB("Mid Warehouse Slab", 6.0, 155.0, 100.0, 150.0),
        LARGE_WAREHOUSE_SLAB("Large Warehouse Slab", 6.0, 155.0, 150.0, 200.0),
        DRIVEWAY("Driveway", 4.0, 120.0),
        SIDEWALK("Sidewalk", 3.5, 110.0),
        COMMERCIAL_LOADING_APRON("Commercial Loading Apron", 8.0, 165.0, 60.0, 80.0),
        PARKING_LOT_SECTION("Parking Lot Section", 5.0, 140.0, 100.0, 200.0),
        EQUIPMENT_PAD("Equipment Pad", 6.0, 155.0, 10.0, 10.0),
        DUMPSTER_PAD("Dumpster Pad", 6.0, 150.0, 12.0, 20.0),
        RV_BOAT_STORAGE_SLAB("RV/Boat Storage Slab", 5.0, 135.0, 14.0, 40.0),
        SPORT_COURT("Basketball/Sport Court", 4.0, 125.0, 50.0, 84.0),
        CUSTOM("Custom", 4.0, 130.0);

        private final String displayName;
        private final double defaultThicknessInches;
        private final double defaultCostPerCubicYard;
        // 0 means the preset has no default dimensions (length/width are left as entered)
        private final double defaultLengthFt;
        private final double defaultWidthFt;

        SlabType(String displayName, double defaultThicknessInches, double defaultCostPerCubicYard) {
            this(displayName, defaultThicknessInches, defaultCostPerCubicYard, 0.0, 0.0);
        }

        SlabType(String displayName, double defaultThicknessInches, double defaultCostPerCubicYard,
                 double defaultLengthFt, double defaultWidthFt) {
            this.displayName = displayName;
            this.defaultThicknessInches = defaultThicknessInches;
            this.defaultCostPerCubicYard = defaultCostPerCubicYard;
            this.defaultLengthFt = defaultLengthFt;
            this.defaultWidthFt = defaultWidthFt;
        }

        public String getDisplayName() { return displayName; }
        public double getDefaultThicknessInches() { return defaultThicknessInches; }
        public double getDefaultCostPerCubicYard() { return defaultCostPerCubicYard; }
        public boolean hasDefaultDimensions() { return defaultLengthFt > 0 && defaultWidthFt > 0; }
        public double getDefaultLengthFt() { return defaultLengthFt; }
        public double getDefaultWidthFt() { return defaultWidthFt; }

        @Override
        public String toString() { return displayName; }
    }

    // Project details
    private String projectName;
    private String location;
    private String clientName;
    private String projectDate;
    private SlabType slabType;

    // Work area
    private double lengthFt;
    private double widthFt;
    private double thicknessInches;
    private double wastePercentage;

    // Labor
    private int numberOfEmployees;
    private double hoursPerEmployee;
    private double laborRatePerHour;

    // Costs
    private double concreteCostPerCubicYard;
    private double discountPercentage;
    private double fixedDiscount;

    // ---- Calculated fields ----
    public double getAreaSqFt() {
        return lengthFt * widthFt;
    }

    public double getVolumeCubicFt() {
        double baseVolume = getAreaSqFt() * (thicknessInches / 12.0);
        return baseVolume * (1 + wastePercentage / 100.0);
    }

    public double getVolumeCubicYards() {
        return getVolumeCubicFt() / 27.0;
    }

    public double getTotalLaborHours() {
        return numberOfEmployees * hoursPerEmployee;
    }

    public double getLaborCost() {
        return getTotalLaborHours() * laborRatePerHour;
    }

    /** Raw concrete cost for the exact pad volume, before the waste factor is applied. */
    public double getConcreteMaterialCostBeforeWaste() {
        double baseVolumeCubicYards = getAreaSqFt() * (thicknessInches / 12.0) / 27.0;
        return baseVolumeCubicYards * concreteCostPerCubicYard;
    }

    /** Concrete cost including the waste factor (this is what feeds the subtotal). */
    public double getConcreteMaterialCost() {
        return getVolumeCubicYards() * concreteCostPerCubicYard;
    }

    public double getSubtotal() {
        return getConcreteMaterialCost() + getLaborCost();
    }

    public double getDiscountAmount() {
        double pctDiscount = getSubtotal() * (discountPercentage / 100.0);
        return pctDiscount + fixedDiscount;
    }

    public double getTotalProjectCost() {
        return getSubtotal() - getDiscountAmount();
    }

    // ---- Getters & Setters ----
    public String getProjectName() { return projectName; }
    public void setProjectName(String projectName) { this.projectName = projectName; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getClientName() { return clientName; }
    public void setClientName(String clientName) { this.clientName = clientName; }

    public String getProjectDate() { return projectDate; }
    public void setProjectDate(String projectDate) { this.projectDate = projectDate; }

    public SlabType getSlabType() { return slabType; }
    public void setSlabType(SlabType slabType) { this.slabType = slabType; }

    public double getLengthFt() { return lengthFt; }
    public void setLengthFt(double lengthFt) { this.lengthFt = lengthFt; }

    public double getWidthFt() { return widthFt; }
    public void setWidthFt(double widthFt) { this.widthFt = widthFt; }

    public double getThicknessInches() { return thicknessInches; }
    public void setThicknessInches(double thicknessInches) { this.thicknessInches = thicknessInches; }

    public double getWastePercentage() { return wastePercentage; }
    public void setWastePercentage(double wastePercentage) { this.wastePercentage = wastePercentage; }

    public int getNumberOfEmployees() { return numberOfEmployees; }
    public void setNumberOfEmployees(int numberOfEmployees) { this.numberOfEmployees = numberOfEmployees; }

    public double getHoursPerEmployee() { return hoursPerEmployee; }
    public void setHoursPerEmployee(double hoursPerEmployee) { this.hoursPerEmployee = hoursPerEmployee; }

    public double getLaborRatePerHour() { return laborRatePerHour; }
    public void setLaborRatePerHour(double laborRatePerHour) { this.laborRatePerHour = laborRatePerHour; }

    public double getConcreteCostPerCubicYard() { return concreteCostPerCubicYard; }
    public void setConcreteCostPerCubicYard(double concreteCostPerCubicYard) { this.concreteCostPerCubicYard = concreteCostPerCubicYard; }

    public double getDiscountPercentage() { return discountPercentage; }
    public void setDiscountPercentage(double discountPercentage) { this.discountPercentage = discountPercentage; }

    public double getFixedDiscount() { return fixedDiscount; }
    public void setFixedDiscount(double fixedDiscount) { this.fixedDiscount = fixedDiscount; }
}