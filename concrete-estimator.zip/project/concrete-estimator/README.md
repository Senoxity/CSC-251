# 🏗️ Concrete Pad Construction Estimator

A Java Swing desktop application for calculating and generating estimates for concrete pad construction projects.

---

## Features

### Core Features
- **Project Details** — Enter project name, location, client name, date
- **Slab Type Presets** — Residential Pad, Garage / Workshop Pad, Small / Mid / Large Warehouse Slab, Driveway, Sidewalk, Commercial Loading Apron, Parking Lot Section, Equipment Pad, Dumpster Pad, RV/Boat Storage Slab, Basketball/Sport Court, Custom
- **Work Area Calculations** — Length × Width area + volume from slab thickness (cu yd)
- **Waste Percentage** — Adds configurable waste factor to concrete volume
- **Labor Estimation** — Number of employees × hours/employee = total labor hours & cost
- **Cost Breakdown** — Concrete material cost, labor cost, subtotal, discount, and grand total
- **Discount System** — Both percentage discount and fixed dollar discount supported

### CSV Integration
- **estimates.csv** — Full project record saved on each estimate (all fields)
- **labor_log.csv** — Manpower hours & work hours log
- **Saved Estimates Tab** — View all past estimates in a scrollable table within the app

---

## Requirements

- Java JDK 11 or higher  
- Download from: https://adoptium.net/

Check your Java version:
```
java -version
```

---

## Build & Run

### Windows
```bat
build_and_run.bat
```

### Mac / Linux
```bash
chmod +x build_and_run.sh
./build_and_run.sh
```

### Run pre-built JAR (after building once)
```bash
java -jar ConcreteEstimator.jar
```

---

## Project Structure

```
concrete-estimator/
├── src/main/java/com/concrete/
│   ├── Main.java                    ← Entry point
│   ├── model/
│   │   └── Project.java             ← Data model + calculations
│   ├── service/
│   │   └── CsvService.java          ← CSV read/write
│   └── ui/
│       └── EstimatorApp.java        ← Swing GUI
├── build_and_run.bat               ← Windows build script
├── build_and_run.sh                ← Mac/Linux build script
└── README.md
```

---

## Chain-Link Fence Estimator

The **Chain-Link Fence** tab is a separate estimator and does not change concrete-pad calculations or saved pad estimates. It includes presets for 4 ft residential/light mesh, 6 ft standard residential, 8 ft heavy-duty, 10 ft commercial, and 6 ft privacy-slat fences, plus custom settings. Enter perimeter, gate opening width/count, fence height, mesh gauge, post spacing/type, top treatment, unit prices, labor assumptions, and discount to calculate an estimate.

Fence estimates are saved separately to `imports_exports/fence_estimates.csv` and can be imported with **Import Fence CSV**. They are never appended to `estimates.csv` or `labor_log.csv`. The post and concrete quantities are planning estimates: terminal posts are approximated as four corner/end posts plus two per gate, and one 60 lb concrete bag is budgeted per post. Verify quantities against the actual fence layout and local installation practices.

## CSV Output Format

### estimates.csv
`Date, ProjectName, Location, ClientName, SlabType, LengthFt, WidthFt, ThicknessIn, WastePct, AreaSqFt, VolumeCuYd, Employees, HrsPerEmployee, TotalLaborHrs, LaborRate, ConcreteCostPerCuYd, ConcreteMaterialCost, LaborCost, DiscountPct, FixedDiscount, DiscountAmount, TotalCost, ConcreteMaterialCostBeforeWaste`

`ConcreteMaterialCost` is the concrete cost *with* waste; `ConcreteMaterialCostBeforeWaste` is the raw cost without it. Older 22-column files still load, and their header is upgraded automatically on the next save.

### labor_log.csv
`Date, ProjectName, Employees, HoursPerEmployee, TotalManpowerHours, LaborRate, TotalLaborCost`

### fence_estimates.csv
`Date,ProjectName,PerimeterFt,GateOpeningFt,FenceHeightFt,MeshGauge,PostSpacingFt,PostType,TopTreatment,FenceFabricFt,LinePosts,TerminalPosts,ConcreteBags,TopRailFt,MaterialCost,LaborHours,LaborRate,DiscountPct,TotalCost`

---

## Slab Type Defaults

| Slab Type                | Thickness (in) | Concrete ($/cu yd) | Length × Width (ft) |
|--------------------------|---------------|---------------------|---------------------|
| Residential Pad          | 4.0           | $125.00             | 20 × 20             |
| Garage / Workshop Pad    | 5.0           | $140.00             | 20 × 40             |
| Small Warehouse Slab     | 6.0           | $155.00             | 50 × 100            |
| Mid Warehouse Slab       | 6.0           | $155.00             | 100 × 150           |
| Large Warehouse Slab     | 6.0           | $155.00             | 150 × 200           |
| Driveway                 | 4.0           | $120.00             | —                   |
| Sidewalk                 | 3.5           | $110.00             | —                   |
| Commercial Loading Apron | 8.0           | $165.00             | 60 × 80             |
| Parking Lot Section      | 5.0           | $140.00             | 100 × 200           |
| Equipment Pad            | 6.0           | $155.00             | 10 × 10             |
| Dumpster Pad             | 6.0           | $150.00             | 12 × 20             |
| RV/Boat Storage Slab     | 5.0           | $135.00             | 14 × 40             |
| Basketball/Sport Court   | 4.0           | $125.00             | 50 × 84             |
| Custom                   | 4.0           | $130.00             | —                   |

Presets with a length × width fill those fields automatically; the others leave them as entered.