// M2 Project: Farm Manager
// Base structure written by Aiden Canady
// Further modifications should be credited a line above whatever was added or changed
import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Product> products = new ArrayList<>();
        ArrayList<Service> services = new ArrayList<>();
        ArrayList<Animal> animals = new ArrayList<>();

        
        FarmDataIO.loadFromCSV("farm_data.csv", products, services, animals);

        boolean running = true;
        while (running) {
            String choice = JOptionPane.showInputDialog(
                "Farm Manager\n" +
                "1. Add a product\n" +
                "2. Sell a product\n" +
                "3. Add a service\n" +
                "4. Mark a service as paid\n" +
                "5. Add an animal\n" +
                "6. Add a breeder animal\n" +
                "7. Sell an animal\n" +
                "8. View all records\n" +
                "9. Import data from CSV\n" +
                "10. Export data to CSV\n" +
                "11. Import data from Excel\n" +
                "12. Exit"
            );

            if (choice == null) break;

            switch (choice) {
                case "1": addProduct(products); break;
                case "2": sellProduct(products); break;
                case "3": addService(services); break;
                case "4": payService(services); break;
                case "5": addAnimal(animals); break;
                case "6": addBreederAnimal(animals); break;
                case "7": sellAnimal(animals); break;
                case "8": viewAll(products, services, animals); break;
                case "9": importCSV(products, services, animals); break;
                case "10": exportCSV(products, services, animals); break;
                case "11": importExcel(products, services, animals); break;
                case "12": running = false; break;
                default: JOptionPane.showMessageDialog(null, "Please enter a number 1-12.");
            }
        }
    }

    private static void importCSV(ArrayList<Product> products, ArrayList<Service> services, ArrayList<Animal> animals) {
        String filename = JOptionPane.showInputDialog("CSV filename to import (e.g. farm_data.csv):");
        if (filename == null || filename.trim().isEmpty()) return;
        FarmDataIO.loadFromCSV(filename.trim(), products, services, animals);
        JOptionPane.showMessageDialog(null, "Import complete.");
    }

    private static void exportCSV(ArrayList<Product> products, ArrayList<Service> services, ArrayList<Animal> animals) {
        String filename = JOptionPane.showInputDialog("Name of exported file (include file extension, ex. farm_export.csv):");
        if (filename == null || filename.trim().isEmpty()) return;
        FarmDataIO.saveToCSV(filename.trim(), products, services, animals);
        JOptionPane.showMessageDialog(null, "Export complete.");
    }

    private static int pickFromList(ArrayList<?> list, String prompt) {
        if (list.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Nothing to choose from yet.");
            return -1;
        }
        Object[] options = list.toArray();
        Object selected = JOptionPane.showInputDialog(
            null, prompt, "Select", JOptionPane.QUESTION_MESSAGE, null, options, options[0]
        );
        return (selected == null) ? -1 : list.indexOf(selected);
    }

    private static void addProduct(ArrayList<Product> products) {
        try {
            String name = JOptionPane.showInputDialog("Product name:");
            double price = Double.parseDouble(JOptionPane.showInputDialog("Price:"));
            int qty = Integer.parseInt(JOptionPane.showInputDialog("Starting quantity:"));
            products.add(new Product(name, price, qty));
            JOptionPane.showMessageDialog(null, "Added: " + name);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Price/quantity must be numbers.");
        }
    }

    private static void sellProduct(ArrayList<Product> products) {
        int index = pickFromList(products, "Which product?");
        if (index == -1) return;
        try {
            int amount = Integer.parseInt(JOptionPane.showInputDialog("How many to sell?"));
            products.get(index).sell(amount);
            JOptionPane.showMessageDialog(null, products.get(index).toString());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "That wasn't a valid number.");
        }
    }

    private static void addService(ArrayList<Service> services) {
        try {
            String desc = JOptionPane.showInputDialog("Service description:");
            double cost = Double.parseDouble(JOptionPane.showInputDialog("Cost:"));
            services.add(new Service(desc, cost));
            JOptionPane.showMessageDialog(null, "Added: " + desc);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Cost must be a number.");
        }
    }

    private static void payService(ArrayList<Service> services) {
        int index = pickFromList(services, "Which service was paid?");
        if (index == -1) return;
        services.get(index).markPaid();
        JOptionPane.showMessageDialog(null, services.get(index).toString());
    }

    private static void addAnimal(ArrayList<Animal> animals) {
        try {
            String species = JOptionPane.showInputDialog("Species (e.g. Chicken, Rabbit):");
            String name = JOptionPane.showInputDialog("Animal's name:");
            double price = Double.parseDouble(JOptionPane.showInputDialog("Price:"));
            animals.add(new Animal(species, name, price));
            JOptionPane.showMessageDialog(null, "Added: " + name);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Price must be a number.");
        }
    }

    private static void addBreederAnimal(ArrayList<Animal> animals) {
        try {
            String species = JOptionPane.showInputDialog("Species:");
            String name = JOptionPane.showInputDialog("Animal's name:");
            double price = Double.parseDouble(JOptionPane.showInputDialog("Price:"));
            String breeder = JOptionPane.showInputDialog("Breeder name:");
            animals.add(new BreederAnimal(species, name, price, breeder));
            JOptionPane.showMessageDialog(null, "Added: " + name + " from " + breeder);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Price must be a number.");
        }
    }

    private static void sellAnimal(ArrayList<Animal> animals) {
        int index = pickFromList(animals, "Which animal was sold?");
        if (index == -1) return;
        animals.get(index).sell();
        JOptionPane.showMessageDialog(null, animals.get(index).toString());
    }

    private static void viewAll(ArrayList<Product> products, ArrayList<Service> services, ArrayList<Animal> animals) {
        StringBuilder sb = new StringBuilder();
        sb.append("--- Products ---\n");
        for (Product p : products) sb.append(p).append("\n");
        sb.append("--- Services ---\n");
        for (Service s : services) sb.append(s).append("\n");
        sb.append("--- Animals ---\n");
        for (Animal a : animals) sb.append(a).append("\n");
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void importExcel(ArrayList<Product> products, ArrayList<Service> services, ArrayList<Animal> animals) {
        String filename = JOptionPane.showInputDialog("Excel filename to import (e.g. farm_data.xlsx):");
        if (filename == null || filename.trim().isEmpty()) return;
        FarmDataIO.loadFromExcel(filename.trim(), products, services, animals);
        JOptionPane.showMessageDialog(null, "Import complete.");
}
}