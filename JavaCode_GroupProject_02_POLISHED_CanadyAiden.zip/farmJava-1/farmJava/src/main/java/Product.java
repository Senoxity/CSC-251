public class Product {
    private String name;
    private double price;
    private int quantityInStock;

    public Product(String name, double price, int quantityInStock) {
        this.name = name;
        this.price = price;
        this.quantityInStock = quantityInStock;
    }

    public void sell(int amount) {
        if (amount > quantityInStock) {
            System.out.println("Not enough stock to sell " + amount + " " + name);
            return;
        }
        quantityInStock -= amount;
        System.out.println("Sold " + amount + " " + name + ". Remaining: " + quantityInStock);
    }

    @Override
    public String toString() {
        return name + " - $" + price + " (" + quantityInStock + " in stock)";
    }

    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getQuantityInStock() { return quantityInStock; }
}