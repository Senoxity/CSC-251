import javax.swing.JOptionPane;
import java.io.*;
import java.util.ArrayList;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class FarmDataIO {
    public static void loadFromCSV(String filename, ArrayList<Product> products,
                                    ArrayList<Service> services, ArrayList<Animal> animals) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line = reader.readLine(); // skip the header row
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] fields = line.split(",");
                String type = fields[0].trim().toUpperCase();

                switch (type) {
                    case "PRODUCT": // type,name,price,quantity
                        products.add(new Product(
                            fields[1].trim(),
                            Double.parseDouble(fields[2].trim()),
                            Integer.parseInt(fields[3].trim())
                        ));
                        break;

                    case "SERVICE": // type,description,cost,paid
                        Service s = new Service(fields[1].trim(), Double.parseDouble(fields[2].trim()));
                        if (Boolean.parseBoolean(fields[3].trim())) s.markPaid();
                        services.add(s);
                        break;

                    case "ANIMAL": // type,species,name,price,sold
                        Animal a = new Animal(fields[1].trim(), fields[2].trim(),
                                               Double.parseDouble(fields[3].trim()));
                        if (Boolean.parseBoolean(fields[4].trim())) a.sell();
                        animals.add(a);
                        break;

                    case "BREEDER": // type,species,name,price,sold,breederName
                        BreederAnimal b = new BreederAnimal(fields[1].trim(), fields[2].trim(),
                                               Double.parseDouble(fields[3].trim()), fields[5].trim());
                        if (Boolean.parseBoolean(fields[4].trim())) b.sell();
                        animals.add(b);
                        break;

                    default:
                        System.out.println("Skipping unrecognized row type: " + type);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Could not read file: " + e.getMessage());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Bad number in file: " + e.getMessage());
        }
    }

    // Writes all current data out to a CSV file.
    public static void saveToCSV(String filename, ArrayList<Product> products,
                                  ArrayList<Service> services, ArrayList<Animal> animals) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            writer.println("type,field1,field2,field3,field4,field5");

            for (Product p : products) {
                writer.println("PRODUCT," + p.getName() + "," + p.getPrice() + "," + p.getQuantityInStock());
            }
            for (Service s : services) {
                writer.println("SERVICE," + s.getDescription() + "," + s.getCost() + "," + s.isPaid());
            }
            for (Animal a : animals) {
                if (a instanceof BreederAnimal) {
                    BreederAnimal b = (BreederAnimal) a; // downcast: treat it specifically as a BreederAnimal
                    writer.println("BREEDER," + b.getSpecies() + "," + b.getName() + "," +
                                    b.getPrice() + "," + b.isSold() + "," + b.getBreederName());
                } else {
                    writer.println("ANIMAL," + a.getSpecies() + "," + a.getName() + "," +
                                    a.getPrice() + "," + a.isSold());
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Could not save file: " + e.getMessage());
        }
    }

    public static void loadFromExcel(String filename, ArrayList<Product> products,
                                  ArrayList<Service> services, ArrayList<Animal> animals) {
    try (FileInputStream fis = new FileInputStream(filename);
         Workbook workbook = new XSSFWorkbook(fis)) {

        Sheet sheet = workbook.getSheetAt(0); // first tab in the workbook

        for (Row row : sheet) {
            if (row.getRowNum() == 0) continue; // skip header row

            String type = getCellValueAsString(row.getCell(0)).toUpperCase();
            if (type.isEmpty()) continue;

            switch (type) {
                case "PRODUCT":
                    products.add(new Product(
                        getCellValueAsString(row.getCell(1)),
                        Double.parseDouble(getCellValueAsString(row.getCell(2))),
                        (int) Double.parseDouble(getCellValueAsString(row.getCell(3)))
                    ));
                    break;

                case "SERVICE":
                    Service s = new Service(
                        getCellValueAsString(row.getCell(1)),
                        Double.parseDouble(getCellValueAsString(row.getCell(2)))
                    );
                    if (Boolean.parseBoolean(getCellValueAsString(row.getCell(3)))) s.markPaid();
                    services.add(s);
                    break;

                case "ANIMAL":
                    Animal a = new Animal(
                        getCellValueAsString(row.getCell(1)),
                        getCellValueAsString(row.getCell(2)),
                        Double.parseDouble(getCellValueAsString(row.getCell(3)))
                    );
                    if (Boolean.parseBoolean(getCellValueAsString(row.getCell(4)))) a.sell();
                    animals.add(a);
                    break;

                case "BREEDER":
                    BreederAnimal b = new BreederAnimal(
                        getCellValueAsString(row.getCell(1)),
                        getCellValueAsString(row.getCell(2)),
                        Double.parseDouble(getCellValueAsString(row.getCell(3))),
                        getCellValueAsString(row.getCell(5))
                    );
                    if (Boolean.parseBoolean(getCellValueAsString(row.getCell(4)))) b.sell();
                    animals.add(b);
                    break;

                default:
                    System.out.println("Skipping unrecognized row type: " + type);
            }
        }

    } catch (IOException e) {
        JOptionPane.showMessageDialog(null, "Could not read Excel file: " + e.getMessage());
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Bad number in Excel file: " + e.getMessage());
    }
}
    private static String getCellValueAsString(Cell cell) {
        if (cell == null) return "";
        switch (cell.getCellType()) {
            case STRING:  return cell.getStringCellValue().trim();
            case NUMERIC: return String.valueOf(cell.getNumericCellValue());
            case BOOLEAN: return String.valueOf(cell.getBooleanCellValue());
            default:      return "";
        }
    }
}