// DEPRECATED: FILE REPLACED BY MAIN.JAVA
public class farmJavaGUI {
    public static void main(String[] args) {
        // Main method implementation
        Product eggs = new Product ("Eggs", 2.99, 100);
        eggs.sell(10);
    }
}
