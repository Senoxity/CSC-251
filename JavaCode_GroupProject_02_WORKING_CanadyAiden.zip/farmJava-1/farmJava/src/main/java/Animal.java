public class Animal {
    private String species; // "Duck", "Chicken", "Rabbit", etc.
    private String name;
    private double price;
    private boolean sold;

    public Animal(String species, String name, double price) {
        this.species = species;
        this.name = name;
        this.price = price;
        this.sold = false;
    }

    public void sell() {
        sold = true;
    }

    @Override
    public String toString() {
        return species + " named " + name + " - $" + price + (sold ? " [SOLD]" : "");
    }

    public String getSpecies() { return species; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public boolean isSold() { return sold; }
}