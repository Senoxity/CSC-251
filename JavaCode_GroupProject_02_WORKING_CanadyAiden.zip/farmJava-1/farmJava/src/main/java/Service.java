public class Service {
    private String description;
    private double cost;
    private boolean paid;

    public Service(String description, double cost) {
        this.description = description;
        this.cost = cost;
        this.paid = false; // not paid until marked otherwise
    }

    public void markPaid() {
        paid = true;
    }

    @Override
    public String toString() {
        return description + " - $" + cost + " (" + (paid ? "Paid" : "Unpaid") + ")";
    }

    public String getDescription() { return description; }
    public double getCost() { return cost; }
    public boolean isPaid() { return paid; }
}