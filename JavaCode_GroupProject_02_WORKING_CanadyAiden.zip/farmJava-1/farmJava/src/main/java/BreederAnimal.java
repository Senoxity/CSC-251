public class BreederAnimal extends Animal {
    private String breederName;

    public BreederAnimal(String species, String name, double price, String breederName) {
        super(species, name, price); // calls Animal's constructor
        this.breederName = breederName;
    }

    @Override
    public String toString() {
        return super.toString() + " (from breeder: " + breederName + ")";
    }

    public String getBreederName() { return breederName; }
}